import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;


public class Product {
	
	private Integer Product_Id;
	private String Prodct_Name;
	
	

	public Integer getProduct_Id() {
		return Product_Id;
	}


	public void setProduct_Id(Integer product_Id) {
		Product_Id = product_Id;
	}


	public String getProdct_Name() {
		return Prodct_Name;
	}


	public void setProdct_Name(String prodct_Name) {
		Prodct_Name = prodct_Name;
	}


	public Product(Integer product_Id, String prodct_Name) {
		super();
		Product_Id = product_Id;
		Prodct_Name = prodct_Name;
	}



	public static void main(String[] args) {
		
		
		
		HashSet<Product> setOfStrs = new HashSet<>();
		
		System.out.println("Enter Number of Entries: ");
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		
		
		
		for(int i=1;i<=n;i++) {
			
			System.out.println("Enter ProductId: ");
			int id = input.nextInt();
			input.nextLine();
			
			System.out.println("Enter ProductName: ");
			String name = input.next();
			
			Product p1 = new Product(id,name);
			
			setOfStrs.add(p1);
			
		}
		System.out.println("Search");
		System.out.println("Enter id: ");
		int id = input.nextInt();
		 for (Product val : setOfStrs) {
	            if(val.getProduct_Id().equals(id)) {
	            	System.out.println("Product Id: "+val.getProduct_Id()+" "+"Product Name: "+val.getProdct_Name());
	            	break;
	            }
	            
	        }
		
		 System.out.println("Delete");
		 System.out.println("Enter id: ");
		 int id1 = input.nextInt();
		 setOfStrs.remove(id1);
		 for (Product val : setOfStrs) {
	            
	          System.out.println("Product Id: "+val.getProduct_Id()+" "+"Product Name: "+val.getProdct_Name());
	           
	            
	        }
		
		 

	}

}
