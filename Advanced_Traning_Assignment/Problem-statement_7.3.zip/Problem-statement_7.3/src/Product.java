

public class Product {
	
	private Integer Product_Id;
	private String Prodct_Name;
	
	

	public Integer getProduct_Id() {
		return Product_Id;
	}


	public void setProduct_Id(Integer product_Id) {
		Product_Id = product_Id;
	}


	public String getProdct_Name() {
		return Prodct_Name;
	}


	public void setProdct_Name(String prodct_Name) {
		Prodct_Name = prodct_Name;
	}


	public Product(Integer product_Id, String prodct_Name) {
		super();
		Product_Id = product_Id;
		Prodct_Name = prodct_Name;
	}
}
