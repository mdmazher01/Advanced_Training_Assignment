import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class App {
	
	
	static Scanner input = new Scanner(System.in);
	static HashMap<String, Integer> maps = new HashMap<>();
	
	public static void main(String[] args) {
		
		choice();
	}
	
	public static void choice() {
		String[] arr1 = {"1. Add Number in PhoneBook",
                "2. Search Phone Number",
                "3. Quit"};
		for(String val:arr1) {
			System.out.println(val);
			}
		System.out.println();
		System.out.println("Enter your choice: ");
		int choice2 = input.nextInt();
		switch(choice2) {
		case 1:
			phonebookAdd();
			choice();
			break;
		case 2:
			searchPhonenumber();
			choice();
			break;
		case 3:
			quit();
			
			
		}
		
		
	}
	
	public static void phonebookAdd() {
		System.out.println("Number of Entries: ");
		int n = input.nextInt();
		input.nextLine();
		for(int i=1;i<=n;i++) {
			System.out.println("Enter Name: ");
			String name = input.next();
			System.out.println("Enter Number: ");
			Integer number = input.nextInt();
			input.nextLine();
			maps.put(name,number);
			System.out.println("Data Added:");
		}
		
		
		
	}
	
	
	public static void searchPhonenumber() {
		boolean flag = false;
		System.out.println("Enter Name");
		String name = input.next();
		for (Entry<String, Integer> e : maps.entrySet()) {
			if(e.getKey().equals(name)) {
				System.out.println("Name: "+e.getKey()+" "+"PhoneNumber: "+e.getValue());
				break;
			}
		}
		
		
		
	}
	
	public static void quit() {
		System.out.println("Closing application...");
	}

}
