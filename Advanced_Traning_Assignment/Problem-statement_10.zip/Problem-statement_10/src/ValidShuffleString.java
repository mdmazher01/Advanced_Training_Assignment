

public class ValidShuffleString {
	 
	static boolean valid (String str1, String str2, String str3)
    {
        int i = 0, j = 0, k = 0;
       
        while (k != str3.length())
        {
           
            if (i<str1.length()&&str1.charAt(i) == str3.charAt(k))
                i++;
     
            else if (j<str2.length()&&str2.charAt(j) == str3.charAt(k))
                j++;

            else
                return false;
            
            k++;
        }
     
     
        if (i < str1.length() || j < str2.length())
            return false;
     
        return true;
    }
	
	public static void main(String[] args) {
		
	
		  	String str1 = "abc";
	        String str2 = "def";
	        String str3 = "dabecf";
	        
	        
//	        String str1 = "pqr";
//	        String str2 = "lmno";
//	        String str3 = "plmrqon";
	        
	        if (valid(str1, str2, str3) == true)
	            System.out.printf("%s is valid shuffle of %s and %s", str3, str1, str2);
	        else
	            System.out.printf("%s is not valid shuffle of %s and %s", str3, str1, str2);
		
	}
	
	
	
}
