import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Coin {

	public static void main(String[] args) {
		
		int coin[] = {1,2,5,10,20,50,100,500,2000};
		Set<Integer> ans = new HashSet<Integer> ();
		
		System.out.println("Enter the Value: ");
		Scanner input = new Scanner(System.in);
		int v = input.nextInt();
		input.nextLine();
		int temp=v;
		for(int i=(coin.length)-1;i>=0;i--) {
			while(v >= coin[i]) {
				v -= coin[i];
				ans.add(coin[i]);
			}
		}
		System.out.println("minimum number of " +ans.size()+ "coins and/or notes needed to make the changes for " +temp+ "V Rs.");
	}

}
