package com.training;

public class ProductServiceImpl implements ProductService {
	
	ProductDAOImpl pro = new ProductDAOImpl();

	@Override
	public void insertProduct(String name, int price, int quantity, String catagory, String brand, String model) {

		pro.insertProduct(name, price, quantity, catagory, brand, model);

	}

	@Override
	public void searchById(int id) {
		pro.searchById(id);

	}

	@Override
	public void deleteById(int id) {
		pro.deleteById(id);

	}

	@Override
	public void updateById(int id, String name, int price, int quantity, String catagory, String brand, String model) {
		pro.updateById(id, name, price, quantity, catagory, brand, model);

	}

	@Override
	public void displayAll() {
		pro.displayAll();

	}

	@Override
	public void byCatagory(String catagory) {
		pro.byCatagory(catagory);
		
	}

	@Override
	public void byBrandOrModel(String brand, String model) {
		pro.byBrandOrModel(brand, model);
		
	}

	@Override
	public void byBrandAndModel(String brand, String model) {
		pro.byBrandAndModel(brand, model);
		
	}

	@Override
	public void byBrandOrModelOrCategory(String brand, String model, String category) {
		pro.byBrandOrModelOrCategory(brand, model, category);
		
	}

}
