import java.util.ArrayList;
import java.util.Scanner;

public class App {
	
	static Scanner input = new Scanner(System.in);
	static ArrayList<String> listOfStudent = new ArrayList<>();

	public static void main(String[] args) {
		
		choice();
	}
	
	public static void choice() {
		String[] arr1 = {"1. Add Student",
                "2. Search student",
                "3. Quit"};
		for(String val:arr1) {
			System.out.println(val);
			}
		System.out.println();
		System.out.println("Enter your choice: ");
		int choice2 = input.nextInt();
		switch(choice2) {
		case 1:
			studentAdd();
			choice();
			break;
		case 2:
			searchStudent();
			choice();
			break;
		case 3:
			quit();
			
			
		}
		
		
	}
	
	public static void studentAdd() {
		
		System.out.println("Enter Student Name: ");
		String name = input.next();
		listOfStudent.add(name);
		System.out.println("Data Added:");
		System.out.println(listOfStudent);
	}
	
	
	public static void searchStudent() {
		boolean flag = false;
		System.out.println("Enter Student Name: ");
		String name = input.next();
		for(String val: listOfStudent) {
			if(val.equals(name)) {
				flag = true;
				break;
			}
			
		}
		if(flag == true) {
			System.out.println("Data found");
		}
		else {
			System.out.println("Data not found");
		}
		
	}
	
	public static void quit() {
		System.out.println("Closing application...");
	}
}
