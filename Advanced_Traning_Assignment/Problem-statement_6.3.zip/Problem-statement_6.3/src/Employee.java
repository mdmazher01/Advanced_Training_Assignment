
public class Employee {
	
	private Integer EmployeeNo;
	private String EmployeeName;
	private String EmployeeAddress;
	
	
	public Employee(Integer EmployeeNo, String EmployeeName, String EmployeeAddress) {
		this.EmployeeNo = EmployeeNo;
		this.EmployeeName = EmployeeName;
		this.EmployeeAddress = EmployeeAddress;
	}


	

	public Integer getEmployeeNo() {
		return EmployeeNo;
	}


	public void setEmployeeNo(Integer employeeNo) {
		EmployeeNo = employeeNo;
	}


	public String getEmployeeName() {
		return EmployeeName;
	}


	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}


	public String getEmployeeAddress() {
		return EmployeeAddress;
	}


	public void setEmployeeAddress(String employeeAddress) {
		EmployeeAddress = employeeAddress;
	}
	
	
	
	
}
